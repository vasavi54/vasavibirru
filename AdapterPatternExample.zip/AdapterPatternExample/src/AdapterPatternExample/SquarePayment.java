package AdapterPatternExample;

public class SquarePayment {
    public void transferPayment(double amount) {
        System.out.println("Payment of $" + amount + " made through Square.");
    }
}
