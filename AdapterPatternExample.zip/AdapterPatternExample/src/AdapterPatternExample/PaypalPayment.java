package AdapterPatternExample;

public class PaypalPayment {
    public void sendPayment(double amount) {
        System.out.println("Payment of $" + amount + " made through PayPal.");
    }
}
