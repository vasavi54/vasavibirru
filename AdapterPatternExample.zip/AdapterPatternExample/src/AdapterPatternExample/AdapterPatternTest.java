package AdapterPatternExample;


public class AdapterPatternTest {
 public static void main(String[] args) {
     
     
     PaypalPayment paypalGateway = new PaypalPayment();
     PaymentProcessor paypalAdapter = new PaypalPaymentAdapter(paypalGateway);
     paypalAdapter.processPayment(200.00);

     
     SquarePayment squareGateway = new SquarePayment();
     PaymentProcessor squareAdapter = new SquarePaymentAdapter(squareGateway);
     squareAdapter.processPayment(300.00);
 }
}
