package AdapterPatternExample;

public class SquarePaymentAdapter implements PaymentProcessor {
    private SquarePayment squareGateway;

    public SquarePaymentAdapter(SquarePayment squareGateway) {
        this.squareGateway = squareGateway;
    }

    @Override
    public void processPayment(double amount) {
        squareGateway.transferPayment(amount);
    }
}
