package AdapterPatternExample;

public class PaypalPaymentAdapter implements PaymentProcessor {
    private PaypalPayment paypalGateway;

    public PaypalPaymentAdapter(PaypalPayment paypalGateway) {
        this.paypalGateway = paypalGateway;
    }

    @Override
    public void processPayment(double amount) {
        paypalGateway.sendPayment(amount);
    }
}
